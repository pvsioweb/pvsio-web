#!/bin/bash
echo "Building PVSio-web Network Controller..."
ant clean -buildfile sapere-javaee.xml &> clean.log
rm -rf out
ant all -buildfile sapere-javaee.xml
echo "Done!"
