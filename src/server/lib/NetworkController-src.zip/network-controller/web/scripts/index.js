/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50, browser:true*/
/*global require*/

require.config({
    baseUrl: './scripts/js-modules',
    paths: {
        NCMonitor: 'NCMonitor'
    }
});
/**
 * Loading the module PVSioWebClient.
 */
require([
    'NCMonitor'
], function (NCMonitor) {

    /**
     * NCMonitor preferences
     */
    var error_mode = false;
    var debugging_mode_backend = false;
    var debugging_mode_frontend = false;
    var extended_mode = true;

    function errorMessage(event) {
        if (error_mode) {
            console.log("!!! " + event.message);
        }
    }

    function notifyMessage(event) {
        if (debugging_mode_frontend) {
            console.log(">>> " + event.message);
        }
    }

    var ncMonitor = new NCMonitor({
        extended: extended_mode,
        debugging: debugging_mode_backend
    });
    ncMonitor.addListener("error", errorMessage);
    ncMonitor.addListener("notify", notifyMessage);


    ncMonitor.start();

    $(window).resize(function () {
        ncMonitor.printConnectionsSapere();
    });

    $(document).ready(function () {
        $('.tooltip').tooltipster();
    });

    $('#toggle_front_debugging').click(function () {
        debugging_mode_frontend = !debugging_mode_frontend;
    });

    $('#toggle_back_debugging').click(function () {
        if (debugging_mode_backend) {
            debugging_mode_backend = false;
            ncMonitor.deactivateDebug();
        }
        else {
            debugging_mode_backend = true;
            ncMonitor.activateDebug();
        }
    });

    $('#toggle_errors').click(function () {
        error_mode = !error_mode;
    });


});