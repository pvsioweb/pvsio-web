/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50, browser:true*/
/*global require*/

require.config({
    baseUrl: './scripts/js-modules',
    paths: {
        NCMonitor: 'NCMonitor-extended'
    }
});
/**
 * Loading the module PVSioWebClient.
 */
require([
    'NCMonitor'
], function (NCMonitor) {

    function errorMessage(event) {
        console.log("!!! " + event.message);
    }

    function notifyMessage(event) {
        console.log(">>> " + event.message);
    }

    var ncMonitor = new NCMonitor({});
    ncMonitor.addListener("error", errorMessage);
    ncMonitor.addListener("notify", notifyMessage);


    ncMonitor.start();

    $(window).resize(function () {
        ncMonitor.printConnectionsSapere();
    });

    $(document).ready(function () {
        $('.tooltip').tooltipster();
    });

});