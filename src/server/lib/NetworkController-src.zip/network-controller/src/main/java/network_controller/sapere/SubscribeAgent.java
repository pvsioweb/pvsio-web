/**
 * @module SapereSpace
 * @version 1.0
 * @description
 *
 * Extension of SapereAgent.
 * It it an SapereAgent meant to be used only to receive data from a PublishAgent,
 * hence to be subscribed to a PublishAgent.
 *
 * @author Piergiuseppe Mallozzi
 * @date 20/05/15 11:13:00 AM
 */

package network_controller.sapere;

import eu.sapere.middleware.agent.SapereAgent;
import eu.sapere.middleware.lsa.Property;
import eu.sapere.middleware.lsa.interfaces.ILsa;
import eu.sapere.middleware.node.notifier.event.*;
import network_controller.communication_interface.NCAgent_Interface;
import network_controller.handlers.SapereHandler;
import network_controller.json.JsonHelper;
import network_controller.logger.NCLogger;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.json.stream.JsonParsingException;
import java.io.StringReader;
import java.util.Iterator;


public class SubscribeAgent extends SapereAgent {


	private String deviceID;
	private String publisherID;
	private String subscribingKey;

	private SapereHandler sapereHandler;

	private NCAgent_Interface subAgent;
	private NCAgent_Interface pubAgent;

	private NCLogger ncLogger;

	/**
	 * Constructor
	 * @param subAgent NCAgent_Interface, every SubscribeAgent is related to one and only NCAgent_Interface
	 * @param pubAgent NCAgent_Interface connected to the Device it wants to subscribe to.
	 *                   This Device, related to a NCAgent_Interface, that has a PublishAgent
	 * DeviceID -> Device (sending data) -> NCAgent_Interface (publisher) -> PublishAgent -> SubscribeAgent -> NCAgent_Interface (subscriber) -> Device (receiving data)
	 * @param sapereHandler SapereHandler, used to call some callback-functions
	 * @param ncLogger NCLogger, used to send logging information
	 */
	public SubscribeAgent(NCAgent_Interface subAgent, NCAgent_Interface pubAgent, SapereHandler sapereHandler, NCLogger ncLogger) {
		super(subAgent.getDeviceID() + "-subTo-" + pubAgent.getDeviceID());
		this.deviceID = subAgent.getDeviceID();
		this.subAgent = subAgent;
		this.pubAgent = pubAgent;
		this.publisherID = pubAgent.getDeviceID();
		this.sapereHandler = sapereHandler;
		this.ncLogger = ncLogger;
	}

	/**
	 * NCAgent_Interface getter, every SubscribeAgent is related to one and only NCAgent_Interface
	 * @return NCAgent_Interface
	 */
	public NCAgent_Interface getINcAgent() {
		return subAgent;
	}

	/**
	 * NCAgent_Interface getter, every SubscribeAgent is related to one and only NCAgent_Interface
	 * @return NCAgent_Interface
	 */
	public String getPublisherID() {
		return publisherID;
	}

	/**
	 * DeviceID getter, SubscribeAgent -> NCAgent_Interface -> Device -> DeviceID
	 * @return String DeviceID
	 */
	public String getDeviceID() {
		return deviceID;
	}

	/**
	 * SubscribingKey getter
	 * In order to receive data a PublishAgent needs to be publishing to the same key
	 * @return String PublishingKey
	 */
	public String getSubscribingKey() {
		return subscribingKey;
	}

	/**
	 * API invoked in order to activate the decay of the SapereAgent
	 * Callback function when successfully decayed: onDecayedNotification
	 */
	public void decay(){
		this.addDecay(1);
		this.submitOperation();
	}

	/**
	 * Inject the SubscribeAgent into the Sapere LSA Space.
	 * This function needs to be invoked once at the creation of the SubscribeAgent
	 */
	@Override
	public void setInitialLSA(){
		subscribingKey = publisherID + "-data";
		addProperty(new Property(subscribingKey, "*"));
		this.submitOperation();

		ncLogger.log(JsonHelper.agentAdd(this));
	}

	/**
	 * Callback function, invoked when a bond has been created.
	 * It means that a PublishAgent is publishing data with key = subscribingKey,
	 * hence the SubscribeAgent is receiving the data
	 * @param event BondAddedEvent
	 */
	@Override
	public void onBondAddedNotification(BondAddedEvent event) {

		ILsa l = event.getBondedLsa();

		Iterator<Property> ip = l.getProperties();
		while (ip.hasNext()) {
			Property p = ip.next();
			String data = p.getPropertyValue().toString().substring(1, p.getPropertyValue().toString().length() - 1);
			subAgent.onSubscribe(pubAgent, data);
			ncLogger.log(JsonHelper.bondAdded(publisherID, deviceID, subscribingKey));
		}
	}

	/**
	 * Callback function, invoked when a bond has been updated.
	 * It means that a PublishAgent is publishing data with key = subscribingKey,
	 * hence the SubscribeAgent is receiving the new data published
	 * @param event BondedLsaUpdateEvent
	 */
	@Override
	public void onBondedLsaUpdateEventNotification(BondedLsaUpdateEvent event) {
		ILsa l = event.getLsa();

		Iterator<Property> ip = l.getProperties();
		while (ip.hasNext()) {
			ncLogger.log(JsonHelper.bondUpdate(publisherID, deviceID, subscribingKey));
			Property p = ip.next();
			String data = p.getPropertyValue().toString().substring(1, p.getPropertyValue().toString().length()-1);
			try { // json
				JsonReader reader = Json.createReader(new StringReader(data));
				JsonObject jsonMessage = reader.readObject();
				// Propagate the message only to the destined device
				if (getDeviceID().equals(jsonMessage.getString("to"))) {
					ncLogger.log(JsonHelper.msgUpdate(publisherID, deviceID, subscribingKey));
					subAgent.onSubscribe(pubAgent, data);
				}
			} catch (JsonParsingException e) { // no json
				subAgent.onSubscribe(pubAgent, data);
			}
		}
	}

	/**
	 * Callback function, executed when the PublishAgent is successfully decayed from Sapere Space
	 * @param event DecayedEvent
	 */
	@Override
	public void onDecayedNotification(DecayedEvent event) {

		sapereHandler.onSubscribeDecayed(this, subAgent);
	}


	/**
	 * The following implementations make no-sense for the purpose of the PublishAgent, hence it won't be implemented
	 */


	@Override
	public void onPropagationEvent(PropagationEvent event) {
	}

	@Override
	public void onBondRemovedNotification(BondRemovedEvent event) {
	}

	@Override
	public void onLsaUpdatedEvent(LsaUpdatedEvent event) {
	}

	@Override
	public void onReadNotification(ReadEvent readEvent) {
	}


}


