/**
 * @module NCAgent
 * @version 1.0
 * @description
 *
 * Implementation of INCAgent.
 * Every INCAgent is strictly bonded to a Device.
 * It implements the APIs for managing the Device inside the Network Controller Space.
 *
 * @author Piergiuseppe Mallozzi
 * @date 20/05/15 11:13:00 AM
 */

package network_controller.sapere_interface;

import network_controller.handlers.AgentsHandler;
import network_controller.handlers.SapereHandler;
import network_controller.handlers.SessionsHandler;


public class NCAgent implements INCAgent {

	private String deviceID;

	private SapereHandler sapereHandler;
	private SessionsHandler sessionsHandler;
	private AgentsHandler agentHandler;

	/**
	 * Constructor
	 * @param deviceID ID of the Device the NCAgent is bond to
	 * @param sapereHandler SessionsHandler, needed to execute some callback-functions
	 * @param sessionsHandler SessionsHandler, needed to execute some callback-functions
	 * @param agentHandler AgentsHandler, needed to execute some callback-functions
	 */
	public NCAgent(String deviceID, SapereHandler sapereHandler, SessionsHandler sessionsHandler, AgentsHandler agentHandler){

		this.sapereHandler = sapereHandler;
		this.sessionsHandler = sessionsHandler;
		this.deviceID = deviceID;
		this.agentHandler = agentHandler;
	}

	/**
	 * Every NCAgent is bonded to one and only Device
	 * @return String with the ID of the Device
	 */
	public String getDeviceID() {

		return deviceID;
	}

	/**
	 * Creates and Inject into the Space a INCAgent Publisher
	 */
	public void injectPublisher(){

		sapereHandler.injectPublisher(this);
	}

	/**
	 * Update the data being published by a Publisher with the message
	 * @param message Data that needs to be published
	 */
	public void publish(String message) {

		sapereHandler.updateData(this, message);
	}

	/**
	 * Subscribes this INCAgent to incAgent INCAgent
	 * @param incAgent INCAgent to subscribe to
	 * @param duplex if true also incAgent INCAgent is subscribing to this INCAgent
	 */
	public void subscribe(INCAgent incAgent, boolean duplex){

		sapereHandler.injectSubscriber(this, incAgent, duplex);
	}

	/**
	 * Subscribes this INCAgent to all other INCAgents present in the Network Controller Space
	 * @param duplex if true all the others INCAgents will subscribe to this INCAgent
	 */
	public void subscribeToAll (boolean duplex){

		sapereHandler.subscribeToAll(this, duplex);
	}

	/**
	 * Request the removal of the INCAgent
	 */
	public void remove(){

		sapereHandler.remove(this);
	}

	/**
	 * Callback - INCAgents has being successfully injected in the Network Controller Space
	 */
	public void onInjected(){

		sessionsHandler.setDeviceON(deviceID);
	}

	/**
	 * Callback - INCAgents has no more Publisher or Subscriber connected to it
	 */
	public void onRemove(){

		sessionsHandler.setDeviceOFF(deviceID);
		agentHandler.onRemove(this);
		sessionsHandler.checkDeviceRemove(deviceID);
	}

	/**
	 * Callback - INCAgents has Published the data
	 * @param message String containing the message correctly published
	 */
	public void onPublish(String message) {

	}

	/**
	 * Callback - INCAgents has received an updated from one of his Subscriptions
	 * @param from INCAgent subscribed to, that originated the message
	 * @param message String containing the message
	 */
	public void onSubscribe(INCAgent from, String message) {

		sessionsHandler.sendToDevice(from.getDeviceID(), deviceID, message);
	}

	/**
	 * Callback - Used to signals errors
	 * @param error String containing the error message
	 */
	public void onError(String error) {

	}

	/**
	 * Remove the subscription between this INCAgent and the incAgent INCAgent
	 *
	 * @param incAgent INCAgent subscribed to
	 * @param duplex   if true also incAgent INCAgent is unSubscribing from this INCAgent
	 */
	public void unSubscribe(INCAgent incAgent, boolean duplex) {

        sapereHandler.revokeSubscriber(this, incAgent);
	}

	/**
	 * Callback - INCAgents been successfully unsubscribed from the Device with id = 'from'
	 *
	 * @param from deviceID unsubscribed from
	 */
	public void onUnSubscribe(String from) {

	}

}


