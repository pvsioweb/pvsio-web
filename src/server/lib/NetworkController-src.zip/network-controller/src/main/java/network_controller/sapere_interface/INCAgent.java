/**
 * @module INCAgent
 * @version 1.0
 * @description
 *
 * Interface INCAgent, it defines the API used for managing the Device inside the Network Controller Space
 * Every INCAgent is strictly bonded to a Device.
 *
 * @author Piergiuseppe Mallozzi
 * @date 20/05/15 11:13:00 AM
 */

package network_controller.sapere_interface;


public interface INCAgent {

	/**
	 * Every NCAgent is bonded to one and only Device
	 * @return String with the ID of the Device
	 */
	String getDeviceID();

	/**
	 * Creates and Inject into the Network Controller Space a INCAgent Publisher
	 */
	void injectPublisher();

	/**
	 * Update the data being published by a Publisher with the message
	 * @param message Data that needs to be published
	 */
	void publish(String message);

	/**
	 * Subscribes this INCAgent to incAgent INCAgent
	 * @param incAgent INCAgent to subscribe to
	 * @param duplex if true also incAgent INCAgent is subscribing to this INCAgent
	 */
	void subscribe (INCAgent incAgent, boolean duplex);

	/**
	 * Subscribes this INCAgent to all other INCAgents present in the Network Controller Space
	 * @param duplex if true all the others INCAgents will subscribe to this INCAgent
	 */
	void subscribeToAll (boolean duplex);

	/**
	 * Remove the subscription between this INCAgent and the incAgent INCAgent
	 * @param incAgent INCAgent subscribed to
	 * @param duplex if true also incAgent INCAgent is unSubscribing from this INCAgent
	 */
	void unSubscribe(INCAgent incAgent, boolean duplex);

	/**
	 * Request the removal of the INCAgent
	 */
	void remove();

	/**
	 * Callback - INCAgents has being successfully injected in the Network Controller Space
	 */
	void onInjected();

	/**
	 * Callback - INCAgents has no more Publisher or Subscriber connected to it
	 */
	void onRemove();

	/**
	 * Callback - INCAgents has Published the data
	 * @param message String containing the message correctly published
	 */
	void onPublish(String message);

	/**
	 * Callback - INCAgents has received an updated from one of his Subscriptions
	 * @param from INCAgent subscribed to, that originated the message
	 * @param message String containing the message
	 */
	void onSubscribe(INCAgent from, String message);

	/**
	 * Callback - INCAgents been successfully unsubscribed from the Device with id = 'from'
	 *
	 * @param from deviceID unsubscribed from
	 */
	void onUnSubscribe(String from);

	/**
	 * Callback - Used to signals errors
	 * @param error String containing the error message
	 */
	void onError(String error);


}


