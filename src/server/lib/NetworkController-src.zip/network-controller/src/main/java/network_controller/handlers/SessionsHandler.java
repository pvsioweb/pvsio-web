/**
 * @module SessionsHandler
 * @version 1.0
 * @description SessionsHandler is a Java Bean that contains all the data structures and the relative functions
 * for managing Sessions and Devices. A Session can register multiple Devices. <br>
 * Like the other handlers it persists across the entire duration of an application (ApplicationScoped).
 * @author Piergiuseppe Mallozzi
 * @date 19/05/15 21:00:00 AM
 */

package network_controller.handlers;

import network_controller.json.JsonHelper;
import network_controller.logger.NCLogger;
import network_controller.model.Device;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.json.JsonObject;
import javax.websocket.Session;
import java.io.IOException;
import java.util.*;

// TODO Fast Refreshing Bug
// TODO UniqueIDs in devices

@ApplicationScoped
public class SessionsHandler {

    private final Set<Session> sessions = new HashSet<Session>();
    private final Set<Device> devices = new HashSet<Device>();
    /**
     * Only needed to Turn OFF the device before removing it
     */
    @Inject
    private AgentsHandler agentsHandler;
    @Inject
    private NCLogger ncLogger;
    private Map<Session, List<Device>> session_devices = new HashMap<Session, List<Device>>();
    private Map<Session, Boolean[]> monitors = new HashMap<Session, Boolean[]>();

    /**
     * List of Devices that need to be removed but are waiting for all their Agents to successfully decay first
     */
    private ArrayList<String> waitForLSARevoke = new ArrayList<String>();

    private int requests = 0;

    // TODO 1-1 Session-Device limitation...
    private Map<Session, JsonObject> sessionsQueuingToAdd = new HashMap<Session, JsonObject>();
    private Map<Session, String> sessionsQueuingToRemove = new HashMap<Session, String>();

    /**
     * Check if the Device with deviceID is already added in the Network Controller and in this case if he's associated to the right Session.
     *
     * @param session
     * @param deviceID
     * @return
     */
    public int checkConsistency(Session session, String deviceID) {
        if (devicePresent(deviceID)) {
            Session session1 = getSessionFromDevice(getDeviceById(deviceID));
            if (session1.equals(session)) {
                return 1; // Device present and Session ok
            } else {
                return -1; // Session mismatch
            }
        } else {
            return -2; // Device not present
        }
    }

    /**
     * Unlock all the Add-Remove requests of Devices that have been waiting
     * for the Agents to be properly Added-Removed from the system
     */
    private void unlockRequests() {
        ncLogger.log("  ~~ UNLOCKING-ADD.. ~~ " + sessionsQueuingToAdd.size() + " || " + sessionsQueuingToRemove.size());
        if (!sessionsQueuingToAdd.isEmpty()) {
            Iterator<Map.Entry<Session, JsonObject>> itAdd = sessionsQueuingToAdd.entrySet().iterator();

            while (itAdd.hasNext()) {
                Map.Entry<Session, JsonObject> entry = itAdd.next();
                requests--;
                ncLogger.log("-- REQUESTS -> " + requests);
                addRequest(entry.getKey(), entry.getValue());
            }
        }
        if (!sessionsQueuingToRemove.isEmpty()) {
            Iterator<Map.Entry<Session, String>> itRmv = sessionsQueuingToRemove.entrySet().iterator();
            while (itRmv.hasNext()) {
                Map.Entry<Session, String> entry = itRmv.next();
                requests--;
                ncLogger.log("-- REQUESTS -> " + requests);
                rmvRequest(entry.getKey(), entry.getValue());
            }
        }
    }

    /**
     * Set the debug parameter of the monitor associated to the session
     *
     * @param session
     */
    public void activateDebugging(Session session) {
        Boolean[] options = monitors.get(session);
        options[1] = true;
        monitors.put(session, options);
    }

    /**
     * Reset the debug parameter of the monitor associated to the session
     *
     * @param session
     */
    public void deactivateDebugging(Session session) {
        Boolean[] options = monitors.get(session);
        options[1] = false;
        monitors.put(session, options);
    }

    /**
     * Request of a Device that wants to join the Network Controller.
     * If other requests are pending then the request is added to a queue.
     * @param session Session of the Device
     * @param jsonMessage Add Message
     */
    public void addRequest(Session session, JsonObject jsonMessage) {
        requests++;
        ncLogger.log("++ REQUESTS -> " + requests);
        if (requests == 1) {
            String deviceID = jsonMessage.getString("deviceID");
            String type = jsonMessage.getString("type");
            String description = jsonMessage.getString("description");
            Device device = new Device(deviceID, type, description);
            addDeviceToSession(device, session);
            addDevice(device);
            if (sessionsQueuingToAdd.containsKey(session)) {
                sessionsQueuingToAdd.remove(session);
                ncLogger.log("-- ADDQUEUE -> " + sessionsQueuingToAdd.size());
            }
            requests--;
            ncLogger.log("-- REQUESTS -> " + requests);
            agentsHandler.unlockONRequests();
            unlockRequests();
        } else {
            if (!sessionsQueuingToAdd.containsKey(session)) {
                sessionsQueuingToAdd.put(session, jsonMessage);
                ncLogger.log("++ ADDQUEUE -> " + sessionsQueuingToAdd.size());
            }
        }
    }

    /**
     * Request of a Device that wants to be removed from the Network Controller.
     * If other requests are pending then the request is added to a queue.
     * @param session Session of the Device
     * @param deviceID ID of the Device that needs to be removed.
     */
    public void rmvRequest(Session session, String deviceID) {
        if (devicePresent(deviceID)) {
            Device device = getDeviceById(deviceID);
            requests++;
            ncLogger.log("++ REQUESTS -> " + requests);
            if (requests == 1) {
                if (device.getStatus() == "ON") {
                    waitForLSARevoke.add(deviceID);
                    ncLogger.log("++ WAITLSA -> " + waitForLSARevoke.size());
                    agentsHandler.toggleDevice(deviceID, "ON");
                } else {
                    removeDeviceFromDataStructures(deviceID);
                }
            } else {
                if (!sessionsQueuingToRemove.containsKey(session)) {
                    sessionsQueuingToRemove.put(session, deviceID);
                    ncLogger.log("++ RMVQUEUE -> " + sessionsQueuingToRemove.size());
                }
            }
        }
    }

    /**
     * Register the Session session as a Monitor Session
     * so it will receives all the updates from the state of the Network.
     * @param session Session of the Monitor
     */
    public void registerMonitor(Session session, boolean extended, boolean debugging) {
        Boolean[] options = new Boolean[2];
        options[0] = extended;
        options[1] = debugging;
        monitors.put(session, options);
        ncLogger.log("++ MONSESS -> " + monitors.size());
    }

    /**
     * Remove the Session session from the a Monitor Sessions
     * so it will no longer receives updates from the state of the Network.
     * @param session Session of the Monitor
     */
    public void removeMonitor(Session session) {
        monitors.remove(session);
        ncLogger.log("-- MONSESS -> " + monitors.size());
    }

    /**
     * Link a Device to a Session. A Session can have multiple Devieces registered,
     * but a Device belongs to only one Session.
     * @param device Device that need to be registered
     * @param session Session where the Device belongs
     */
    private void addDeviceToSession(Device device, Session session) {
        if (!session_devices.containsKey(session)) {
            List<Device> devices = new ArrayList<Device>();
            session_devices.put(session, devices);
            ncLogger.log("++ SES-DEV -> " + session_devices.size());
        }
        List<Device> deviceList = session_devices.get(session);
        deviceList.add(device);
        ncLogger.log("++ SES-DEV->DEV-TO-SES -> " + deviceList.size());
    }

    /**
     * Remove a Device from his Session. A Session can have multiple Devieces registered,
     * but a Device belongs to only one Session.
     * @param device Device that need to be removed
     */
    private void removeDeviceFromSession(Device device) {
        Session session = getSessionFromDevice(device);
        List<Device> deviceList = session_devices.get(session);
        deviceList.remove(device);
        ncLogger.log("-- SES-DEV->DEV-TO-SES -> " + deviceList.size());
        if (deviceList.size() == 0) {
            session_devices.remove(session);
            ncLogger.log("-- SES-DEV -> " + session_devices.size());
        }
    }

    /**
     * Remove all the Devices from a Session. A Session can have multiple Devieces registered,
     * but a Device belongs to only one Session.
     * @param session Session containing the Devices.
     */
    public void removeAllDevicesFromSession(Session session) {
        if (session_devices.containsKey(session)) {
            List<Device> deviceList = session_devices.get(session);
            for (Device device : deviceList) {
                rmvRequest(session, device.getDeviceID());
            }
        } else {
            ncLogger.log(JsonHelper.error("No device present in the current session"));
        }
    }

    /**
     * Return the Session of a Device
     * @param device Device registered to a Session.
     */
    public Session getSessionFromDevice(Device device) {

        Session session = null;

        for (Map.Entry<Session, List<Device>> e : session_devices.entrySet()) {

            Session key = e.getKey();
            List<Device> deviceList = e.getValue();
            for (Device dev : deviceList) {
                if (dev == device) {
                    session = key;
                }
            }
        }
        return session;
    }

    /**
     * Registers a new Device Session
     * @param session Session to be registered
     */
    public void addSession(Session session) {
        sessions.add(session);
        ncLogger.log("++ SESSIONS -> " + sessions.size());
    }

    /**
     * Removes the Device Session
     * @param session Session to be removed
     */
    public void removeSession(Session session) {
        sessions.remove(session);
        ncLogger.log("-- SESSIONS -> " + sessions.size());
        removeAllDevicesFromSession(session);
    }

    /**
     * Registers a new Device to the internal data strucutures
     * @param device Device that needs to be registered
     */
    private void addDevice(Device device) {
        devices.add(device);
        ncLogger.log("++ DEVICES -> " + devices.size());
        Session sessionDevice = getSessionFromDevice(device);
        sendToAllMonitors(JsonHelper.add(device));
        sendToSession(sessionDevice, JsonHelper.add(device));
    }

    /**
     * Utility function that checks if a Device is already registered in the internal data structures
     * @param deviceID ID of the Device
     * @return true if the Device is already present
     */
    private boolean devicePresent(String deviceID) {
        boolean res = false;
        for (Device device : devices) {
            if (device.getDeviceID().equals(deviceID)) {
                res = true;
            }
        }
        return res;
    }

    /**
     * Removes a Device from the internal data structures
     * @param deviceID ID of the Device that needs to be removed
     */
    private void removeDeviceFromDataStructures(String deviceID) {
        Device device = getDeviceById(deviceID);
        Session session = getSessionFromDevice(device);
        removeDeviceFromSession(device);
        devices.remove(device);
        ncLogger.log("-- DEVICES -> " + devices.size());
        sendToAllMonitors(JsonHelper.remove(device));
        sendToSession(session, JsonHelper.remove(device));

        if (sessionsQueuingToRemove.containsKey(session)) {
            sessionsQueuingToRemove.remove(session);
            ncLogger.log("-- RMVQUEUE -> " + sessionsQueuingToRemove.size());
        }
        requests--;
        ncLogger.log("-- REQUESTS -> " + requests);
        unlockRequests();
    }

    /**
     * Changes the internal state of a Device to the state "ON"
     * @param deviceID ID of the Device
     */
    public void setDeviceON(String deviceID) {

        Device device = getDeviceById(deviceID);
        if ("OFF".equals(device.getStatus())) {
            device.setStatus("ON");
            sendToAllMonitors(JsonHelper.connected(deviceID));
            Session sessionDevice = getSessionFromDevice(getDeviceById(deviceID));
            sendToSession(sessionDevice, JsonHelper.connected(deviceID));
        }
    }

    /**
     * Changes the internal state of a Device to the state "OFF"
     * @param deviceID ID of the Device
     */
    public void setDeviceOFF(String deviceID) {
        Device device = getDeviceById(deviceID);
        if ("ON".equals(device.getStatus())) {
            device.setStatus("OFF");
            sendToAllMonitors(JsonHelper.disconnected(deviceID));
            Session sessionDevice = getSessionFromDevice(getDeviceById(deviceID));
            sendToSession(sessionDevice, JsonHelper.disconnected(deviceID));
        }
    }

    /**
     * Returns a Device from his ID
     * @param deviceID ID of the Device
     * @return Device
     */
    public Device getDeviceById(String deviceID) {
        for (Device device : devices) {
            if (device.getDeviceID().equals(deviceID)) {
                return device;
            }
        }
        return null;
    }

    /**
     * Sends a JsonObject to the specified Session session
     * @param session Session that needs to receive the message
     * @param message JsonObject with the content of the message
     */
    public void sendToSession(Session session, JsonObject message) {
        try {
            if (sessions.contains(session)) {
                if (session.isOpen()) {
                    session.getBasicRemote().sendText(message.toString());
                }
            }
        } catch (IOException ex) {
            sendToAllMonitors(ex.getMessage());
        }
    }

    /**
     * Sends the String message to the Device with id deviceTo
     * @param deviceFrom ID of the Device sending the message
     * @param deviceTo ID of the Device receiving the message
     * @param message String with the message content
     */
    public void sendToDevice(String deviceFrom, String deviceTo, String message) {
        Device device = getDeviceById(deviceTo);
        Session session = getSessionFromDevice(device);
        sendToSession(session, JsonHelper.update(deviceFrom, message));
    }

    /**
     * Sends the Debug message to all connected Monitors
     * @param message String containing the message to be sent
     */
    public void sendToAllMonitors(String message) {
        try {
            Iterator<Map.Entry<Session, Boolean[]>> it = monitors.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<Session, Boolean[]> entry = it.next();
                if (entry.getValue()[1]) {
                    // if debugging mode is on
                    entry.getKey().getBasicRemote().sendText(message);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Sends the JsonObject message to all connected Monitors
     * @param message String containing the message to be sent
     */
    public void sendToAllMonitors(JsonObject message) {
        try {
            Iterator<Map.Entry<Session, Boolean[]>> it = monitors.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<Session, Boolean[]> entry = it.next();

                // If it's an extended monitor => send everything
                if (entry.getValue()[0]) {
                    entry.getKey().getBasicRemote().sendText(message.toString());
                } else {
                    // Send only certain actions
                    String action = message.getString("action");
                    if (action.equals("add") ||
                            action.equals("remove") ||
                            action.equals("connected") ||
                            action.equals("disconnected")) {
                        entry.getKey().getBasicRemote().sendText(message.toString());
                    }
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Sends the JsonObject message to a specific Monitor
     * @param message JsonObject containing the message to the be sent
     * @param session Session of the Monitor that needs to receive the message
     */
    public void sendToMonitor(JsonObject message, Session session) {
        try {
            session.getBasicRemote().sendText(message.toString());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Sends information about all the Devices currently registered to the Monitor specified.
     * @param session Session of the Monitor receiving the information
     */
    public void sendDataStructuresToMonitor(Session session) {
        for (Device device : devices) {
            JsonObject addMessage = JsonHelper.add(device);
            sendToMonitor(addMessage, session);

            if (device.isConnected()) {
                JsonObject cntMessage = JsonHelper.connected(device.getDeviceID());
                sendToMonitor(cntMessage, session);
            }
        }
    }

    /**
     * Callback function, executed after all the Agents of a NCAgent_Interface dacayed.
     * It check wether or not the dacay was due to a Remove-Device command or a Toggle-Device command.
     * If it was a Remove command then the Device is waiting in the waitForLSARevoke queue in order to be removed.
     * @param deviceID ID of the Device whose Agents all decayed.
     */
    public void checkDeviceRemove(String deviceID) {
        if (waitForLSARevoke.contains(deviceID)) {
            waitForLSARevoke.remove(deviceID);
            ncLogger.log("-- WAITLSA -> " + waitForLSARevoke.size());
            removeDeviceFromDataStructures(deviceID);
        }
    }

    /**
     * Check if a Device with id deviceID is actually queuing to be added to the Network Controller system.
     * It is a usefull funcion when a device needs to be turned ON but it is not yet added correctely to the system.
     *
     * @param deviceID id of the Device
     * @return true if the Device is currently queuing to be added, else false.
     */
    public boolean isDeviceQueuingToBeAdded(String deviceID) {
        if (!sessionsQueuingToAdd.isEmpty()) {
            Iterator<Map.Entry<Session, JsonObject>> itAdd = sessionsQueuingToAdd.entrySet().iterator();

            while (itAdd.hasNext()) {
                Map.Entry<Session, JsonObject> entry = itAdd.next();
                String deviceID1 = entry.getValue().getString("deviceID");
                if (deviceID.equals(deviceID)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }
}