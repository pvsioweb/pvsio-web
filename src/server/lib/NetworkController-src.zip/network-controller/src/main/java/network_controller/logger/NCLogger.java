/**
 * @module NCLogger
 * @version 1.0
 * @description
 * Helper class used by different classes in order to register log-debug messages.
 * Java Bean persisting across the entire duration of an application (ApplicationScoped).
 * @author Piergiuseppe Mallozzi
 * @date 19/05/15 22:00:00
 */

package network_controller.logger;

import network_controller.handlers.SessionsHandler;
import network_controller.json.JsonHelper;
import network_controller.sapere.SapereSpace;

import javax.annotation.PostConstruct;
import javax.enterprise.context.ApplicationScoped;
import javax.inject.Inject;
import javax.json.JsonObject;

@ApplicationScoped
public class NCLogger {

    @Inject
    private SessionsHandler sessionsHandler;

    @Inject
    private JsonHelper jsonHelper;

    private SapereSpace sapereSpace;

    @PostConstruct
    public void startSapereSpace() {
        sapereSpace = new SapereSpace(this);
    }

    /**
     * Sends the message to all registered Monitors
     * @param message String containing the message to be sent
     */
    public void log(String message){

        sessionsHandler.sendToAllMonitors(message);
    }

    /**
     * Sends the jsonObject to all registered Monitors
     * @param jsonObject JsonObject containing the message to be sent
     */
    public void log(JsonObject jsonObject){

        sessionsHandler.sendToAllMonitors(jsonObject);
    }
}