/**
 * @module PublishAgent
 * @version 1.0
 * @description
 *
 * Extension of SapereAgent.
 * It it an SapereAgent meant to be used only to Publish Data.
 *
 * @author Piergiuseppe Mallozzi
 * @date 20/05/15 1:13:00 PM
 */

package network_controller.sapere;

import eu.sapere.middleware.agent.SapereAgent;
import eu.sapere.middleware.lsa.autoupdate.EventGenerator;
import eu.sapere.middleware.node.notifier.event.*;
import network_controller.communication_interface.NCAgent_Interface;
import network_controller.handlers.SapereHandler;
import network_controller.json.JsonHelper;
import network_controller.logger.NCLogger;

public class PublishAgent extends SapereAgent {


	private EventGenerator dataEvent;

	private String deviceID;

	private String publishingKey;

	private SapereHandler sapereHandler;

	private NCAgent_Interface ncAgent_interface;

	private NCLogger ncLogger;

	/**
	 * Constructor
	 * @param ncAgent_interface NCAgent_Interface, every PublishAgent is related to one and only NCAgent_Interface
	 * @param dataEvent EventGenerator, every PublishAgent has one EventGenerator that uses to publish data
	 * @param sapereHandler SapereHandler, used to call some callback-functions
	 * @param ncLogger NCLogger, used to send logging information
	 */
	public PublishAgent(NCAgent_Interface ncAgent_interface, EventGenerator dataEvent, SapereHandler sapereHandler, NCLogger ncLogger) {
		super(ncAgent_interface.getDeviceID() + "-publish");
		this.ncAgent_interface = ncAgent_interface;
		this.dataEvent = dataEvent;
		this.deviceID = ncAgent_interface.getDeviceID();
		this.sapereHandler = sapereHandler;
		this.ncLogger = ncLogger;
	}

	/**
	 * NCAgent_Interface getter, every PublishAgent is related to one and only NCAgent_Interface
	 * @return NCAgent_Interface
	 */
	public NCAgent_Interface getINcAgent() {
		return ncAgent_interface;
	}

	/**
	 * DeviceID getter, PublishAgent -> NCAgent_Interface -> Device -> DeviceID
	 * @return String DeviceID
	 */
	public String getDeviceID() {
		return deviceID;
	}

	/**
	 * PublishingKey getter, All data will be published with this PublishingKey that usually is "'DeviceID'-publish"
	 * In order to receive data a SubscribeAgent needs to be subscribed to the same key
	 * @return String PublishingKey
	 */
	public String getPublishingKey() {
		return publishingKey;
	}

	/**
	 * API invoked to change the data being published
	 * @param data String new data that needs to be published
	 */
	public void publishData(String data){
		dataEvent.autoUpdate(data);
		ncAgent_interface.onPublish(data);
	}

	/**
	 * API invoked in order to activate the decay of the SapereAgent
	 * Callback function when successfully decayed: onDecayedNotification
	 */
	public void decay(){
		this.addDecay(1);
		this.submitOperation();
	}

	/**
	 * Inject the PublishAgent into the Sapere LSA Space.
	 * This function needs to be invoked once at the creation of the PublishAgent
	 */
	@Override
	public void setInitialLSA(){

		publishingKey = deviceID + "-data";
		addProperty(publishingKey, dataEvent);
		this.submitOperation();

		ncLogger.log(JsonHelper.agentAdd(this));
	}

	/**
	 * Callback function, executed when the PublishAgent is successfully decayed from Sapere Space
	 * @param event DecayedEvent
	 */
	@Override
	public void onDecayedNotification(DecayedEvent event) {

		sapereHandler.onPublishDecayed(this, ncAgent_interface);
	}

	/**
	 * The following implementations make no-sense for the purpose of the PublishAgent, hence it won't be implemented
	 */

	@Override
	public void onBondAddedNotification(BondAddedEvent event) {

	}

	@Override
	public void onBondRemovedNotification(BondRemovedEvent event) {
	}

	@Override
	public void onBondedLsaUpdateEventNotification(BondedLsaUpdateEvent event) {
	}

	@Override
	public void onPropagationEvent(PropagationEvent event) {
	}

	@Override
	public void onLsaUpdatedEvent(LsaUpdatedEvent event) {
	}

	@Override
	public void onReadNotification(ReadEvent readEvent) {

	}


}


