package eu.sapere.middleware.node.lsaspace;

import java.util.ArrayList;
import java.util.List;

import eu.sapere.middleware.node.INodeManager;
import eu.sapere.middleware.node.lsaspace.ecolaws.Aggregation;
import eu.sapere.middleware.node.lsaspace.ecolaws.Bonding;
import eu.sapere.middleware.node.lsaspace.ecolaws.Decay;
import eu.sapere.middleware.node.lsaspace.ecolaws.IEcoLaw;
import eu.sapere.middleware.node.lsaspace.ecolaws.Propagation;

/**
 * Manages the exectution of eco-laws.
 * 
 * @author Gabriella Castelli (UNIMORE)
 * @author Graeme Stevenson (STA)
 */
public class EcoLawsEngine {

	// /**
	// * The default frequency for firing eco-laws if not specified in the
	// property file.
	// */
	// private static final int DEFAULT_FIRING_FREQUENCY = 1;
	//
	// /**
	// * The default number of cycles between triggering the eco-laws.
	// */
	// private long my_defaultFrequency;
	//
	// /**
	// * The number of cycles between triggering the eco-laws that involve
	// propagation.
	// */
	// private final long my_spreadFrequency;
	//
	// /**
	// * The number of cycles between triggering the eco-laws that involve
	// direct propagation.
	// */
	// private final long my_directPropagationFrequency;
	//
	// /**
	// * The local sim cycle counter
	// */
	// private long my_cycleCounter = 0;
	//
	/** Identifies a generic eco-law */
	public static final String ECO_LAWS = "EcoLaws";

	/** Identifies the Decay eco-law executor */
	public static final String ECO_LAWS_DECAY = "EcoLawsDecay";

	/** Identifies the Aggregation eco-law executor */
	public static final String ECO_LAWS_AGGREGATION = "EcoLawsAggregation";

	/** Identifies the Propagation eco-law executor */
	public static final String ECO_LAWS_PROPAGATION = "EcoLawsPropagation";

	private final List<IEcoLaw> my_ecoLaws = new ArrayList<IEcoLaw>();

	/**
	 * Creates an instance of the eco-laws engine that manages the execution of
	 * eco-laws.
	 * 
	 * @param space
	 *            The space in which the eco-law executes.
	 * @param opManager
	 *            The OperationManager that manages operations in the space
	 * @param notifier
	 *            The Notifier that notifies sapere_handler whith events happening to
	 *            LSAs
	 * @param networkDeliveryManager
	 *            The interface for Network Delivery of LSAs
	 */
	public EcoLawsEngine(INodeManager nodeManager) {
		// Add the eco-laws in execution order.
		my_ecoLaws.add(new Decay(nodeManager));
		my_ecoLaws.add(new Aggregation(nodeManager));
		my_ecoLaws.add(new Bonding(nodeManager));
		my_ecoLaws.add(new Propagation(nodeManager));
	}

	/**
	 * Launches the ordered execution of eco-laws.
	 */
	public void exec() {
		for (IEcoLaw law : my_ecoLaws)
			law.invoke();
	}
}
