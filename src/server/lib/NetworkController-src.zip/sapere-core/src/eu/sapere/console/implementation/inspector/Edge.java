/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.sapere.console.implementation.inspector;

import java.awt.Color;

/**
 * 
 * @author root
 */
public class Edge {

	/**
     * 
     */
	protected JitterNode from;
	/**
     * 
     */
	protected JitterNode to;
	/**
     * 
     */
	protected boolean elastic = false;
	/**
     * 
     */
	private Color color = Color.RED;

	public void setColor(Color color) {
		this.color = color;
	}

	public Color getColor() {
		return color;
	}

	/**
	 * 
	 * @param from
	 * @param to
	 */
	public Edge(JitterNode from, JitterNode to) {
		this.from = from;
		this.to = to;
	}

	public Edge(JitterNode from, JitterNode to, Color color) {
		this.from = from;
		this.to = to;
		this.color = color;
	}

	public boolean hasEdge(JitterNode node) {
		return ((from == node) || (to == node)) ? true : false;
	}

	public boolean hasEdge(String lsaId) {
		return ((((VisualLSA) from.getUserObject()).getLsaId() == lsaId) || ((((VisualLSA) to
				.getUserObject()).getLsaId() == lsaId))) ? true : false;
	}

}