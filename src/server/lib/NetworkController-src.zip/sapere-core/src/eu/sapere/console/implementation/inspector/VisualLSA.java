package eu.sapere.console.implementation.inspector;

public class VisualLSA {

	private String lsaId = null;
	private String content = null;
	private String status = null;

	private boolean ToBeRemoved = false;
	//private boolean atom = false;
	//private boolean container = false;

	public VisualLSA(String lsaId, String content) {
		this.lsaId = lsaId;
		this.content = content;
		this.status = new String();
	}

	public VisualLSA(String lsaId, String content, String status) {
		this.lsaId = lsaId;
		this.content = content;
		this.status = status;
	}

	public boolean isToBeRemoved() {
		return ToBeRemoved;
	}

	public void setToBeRemoved(boolean toBeRemoved) {
		ToBeRemoved = toBeRemoved;
	}

	public String getLsaId() {
		return lsaId;
	}

	public void setLsaId(String lsaId) {
		this.lsaId = lsaId;
	}

	public boolean isAtom() {
		return false;
	}

	public boolean isContainer() {
		return true;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getContent() {
		return content;
	}

}
