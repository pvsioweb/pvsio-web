/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.sapere.console.implementation.inspector;

import java.util.Random;

/**
 * 
 * @author root
 */
public abstract class JitterNode extends Node {

	private Object userObject = null;

	static Random rng = new Random();
	static int jitter = 20;

	protected static int defaultX = -1;


	
	protected static int defaultY = -1;
	// ------------------------------------------------------------
	// Member variables

	protected int width, height;

	protected int x, y, dx, dy;

	protected boolean fixed = false;

	/** Creates new Node */

	private JitterNode(int x, int y) {
		this.x = (x == -1) ? defaultX + rng.nextInt(jitter) * 4 : x;
		this.y = (y == -1) ? defaultY + rng.nextInt(jitter) * 3 : y;
	}

	/**
	 * 
	 * @param userObject
	 */
	public JitterNode(Object userObject) {
		this(-1, -1);
		this.userObject = userObject;
	}

	/**
	 * 
	 * @param userObject
	 * @param x
	 * @param y
	 */
	public JitterNode(Object userObject, int x, int y) {
		this(x, y);
		this.userObject = userObject;
	}

	public Object getUserObject() {
		return userObject;
	}

	/**
	 * 
	 * @param userObject
	 */
	public void setUserObject(Object userObject) {
		this.userObject = userObject;
	}

	// ------------------------------------------------------------

	/**
	 * Returns the label of this element. Used by the painting method.
	 * 
	 * @return ?
	 */
	public abstract String getLabel();
	// ------------------------------------------------------------
	// Static member variables

}
