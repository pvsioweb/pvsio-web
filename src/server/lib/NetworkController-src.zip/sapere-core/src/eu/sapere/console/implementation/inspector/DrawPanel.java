/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.sapere.console.implementation.inspector;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.AffineTransform;
import java.util.Enumeration;
import java.util.List;
import java.util.Random;
import java.util.Vector;

import javax.swing.JPanel;

/**
 * 
 * @author root
 * @Gabriella Castelli (UNIMORE)
 */
public class DrawPanel extends JPanel implements Runnable, MouseListener,
		MouseMotionListener, KeyListener {


	private static final long serialVersionUID = -4737954215639473532L;
	// public boolean showAtomNodes = false;

	public boolean showHorizon = false;
	private Random rng = new Random();
	private Thread animation;
	private ContentTracker tracker = null;
	private double animationStressFactor = 0.01;
	private int connectionForce = 20; // 60
	private int distractionForce = 30; // 40
	private int samePositionForce = 10; // 10
	private int shearForce = 10; // 10
	/** Node in focus. */
	JitterNode pick;
	/** Is the node in focus a fixed node?. */
	boolean pickfixed;
	boolean stress;

	private static final String DECAY_MSG = "REMOVED by DECAY eco-law";
	//private static final String AGGREGATION_MSG = "REMOVED by AGGREGATION eco-law";
	private static final String PROPAGATION_MSG = "PROPAGATED";
	//private static final String RCM_MSG = "ACTIVELY PROPAGATED by REMOTE CONNECTION MANAGER";

	/**
   * 
   */
	public DrawPanel() {
		addMouseListener(this);
		initComponents();
	}

	private void initComponents() {
		super.setBorder(javax.swing.BorderFactory.createEtchedBorder());
		super.addKeyListener(this);
		super.setFocusable(true);

		super.setBorder(javax.swing.BorderFactory.createEtchedBorder());

		setPreferredSize(new java.awt.Dimension(800, 600));
		addComponentListener(new java.awt.event.ComponentAdapter() {

			@Override
			public void componentResized(java.awt.event.ComponentEvent evt) {
				formComponentResized(evt);
			}
		});
	}

	// ------------------------------------------------------------
	/**
	 * 
	 * @param networkTracker
	 */
	public void setContentTracker(ContentTracker networkTracker) {
		tracker = networkTracker;
	}

	/**
   * 
   */
	public void toggleHorizon() {
		showHorizon = (showHorizon) ? false : true;
	}

	@Override
	public int getHeight() {
		return super.getHeight();
	}

	@Override
	public int getWidth() {
		return super.getWidth();
	}

	// ------------------------------------------------------------
	/**
   * 
   */
	public void startAnimation() {
		if ((animation == null) && (tracker != null)) {
			animation = new Thread(this);
			animation.start();
		}
	}

	/**
   * 
   */
	public void stopAnimation() {
		animation = null;
	}

	/**
	 * The spring balance code is based around a spring balancer algorithm found
	 * in a JDK demo applet.
	 */
	private synchronized void animate() {

		List<?> edgeDoubleList = tracker.getDoubleEdges();
		synchronized (edgeDoubleList) {
			int numberOfEdges = edgeDoubleList.size();
			for (int i = 0; i < numberOfEdges; i++) {
				Edge edge = (Edge) edgeDoubleList.get(i);

				double vx = edge.to.x - edge.from.x;
				double vy = edge.to.y - edge.from.y;
				double f = -0.0005 * getConnectionForce();
				double dx = f * vx;
				double dy = f * vy;

				edge.to.dx += dx;
				edge.to.dy += dy;
				edge.from.dx += -dx;
				edge.from.dy += -dy;
			}
		}

		List<?> NodeList = tracker.getNodes();
		synchronized (NodeList) {
			int numberOfNodes = NodeList.size();
			for (int i = 0; i < numberOfNodes; i++) {
				JitterNode n1 = (JitterNode) NodeList.get(i);
				double dx = 0;
				double dy = 0;

				for (int j = 0; j < numberOfNodes; j++) {
					if (i == j) {
						continue;
					}
					JitterNode n2 = (JitterNode) NodeList.get(j);

					// To prevent Decayed Nodes from moving
					if (!((LsaNode) n1).decayed || !((LsaNode) n2).decayed) {

						double vx = n1.x - n2.x;
						double vy = n1.y - n2.y;
						double len = vx * vx + vy * vy;
						if (len < 0.1) {
							dx += rng.nextDouble() * 0.1
									* getSamePositionForce();
							dy += rng.nextDouble() * 0.1
									* getSamePositionForce();
						} else {
							len = len * len;
							dx += vx / len;
							dy += vy / len;
							double shear = (rng.nextDouble() - 0.5)
									* getShearForce()
									* getAnimationStressFactor();
							dx -= (vx / len) * shear;
							dy += (vy / len) * shear;
						}
					}
					double dlen = dx * dx + dy * dy;
					if (dlen > 0) {
						dlen = Math.sqrt(dlen);
						n1.dx += 0.1 * getDistractionForce() * dx / dlen;
						n1.dy += 0.1 * getDistractionForce() * dy / dlen;
					}
				}

				Dimension d = getSize();
				for (int ii = 0; ii < NodeList.size(); ii++) {
					JitterNode n = (JitterNode) NodeList.get(ii);
					if (!n.isFixed) {
						n.x += n.dx;
						n.y += n.dy;
					}
					if (n.x > d.width - n.width / 2) {
						n.x = d.width - n.width / 2;
					} else if (n.x < n.width / 2) {
						n.x = n.width / 2;
					}
					if (n.y > d.height - n.height) {
						n.y = d.height - n.height;
					} else if (n.y < n.height / 2) {
						n.y = n.height / 2;
					}
					n.dx /= 2;
					n.dy /= 2;
				}
			} // end if ! decayed
		} // end for
	}

	/**
	 * Show values of edge stress?
	 * 
	 * @param value
	 */
	public void setStress(boolean value) {
		stress = value;
	}

	Color hColor = new Color(200, 200, 200);

	private void drawHorizon(Graphics g, Dimension d) {
		g.setColor(hColor);
		double x = d.getWidth();
		double y = d.getHeight();
		double step = 1.0;

		// horizontal
		int yHorizon = (int) (y * 0.7);
		for (int i = 0; i < 15; i++) {
			int yH = yHorizon + (int) step;
			g.drawLine(0, yH, (int) x, yH);
			step = step * 1.5;
		}

		yHorizon++;
		int xMid = (int) (d.getWidth() / 2);
		g.drawLine(xMid, (int) y, xMid, yHorizon);
		int topOffset = xMid / 10;
		int bottomOffset = xMid / 2;
		for (int i = 1; i < 11; i++) {
			g.drawLine((i * bottomOffset) + xMid, (int) y, (i * topOffset)
					+ xMid, yHorizon);
			g.drawLine(xMid - (i * bottomOffset), (int) y, xMid
					- (i * topOffset), yHorizon);
		}
	}

	/**
	 * The display code is based around a spring balancer algorithm found in a
	 * JDK demo applet.
	 */

	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Graphics2D g2d = (Graphics2D) g;

		FontMetrics fm = g2d.getFontMetrics();
		int fh = fm.getHeight();
		int fh2 = fh / 2;

		if (showHorizon) {
			drawHorizon(g, getSize());
		}

		if (tracker != null) {

			g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
					RenderingHints.VALUE_ANTIALIAS_ON);
			g2d.setStroke(new BasicStroke(2, BasicStroke.CAP_ROUND,
					BasicStroke.JOIN_ROUND)); // sets width of lines

			// Draw Double Edges
			List<Edge> edgesDouble = tracker.getDoubleEdges();
			synchronized (edgesDouble) {
				for (Edge edge : edgesDouble) {
					g2d.setColor(edge.getColor());
					drawArrow(g2d, edge.from.x, edge.from.y, edge.to.x,
							edge.to.y, true);
				}
			}

			// Draw Single Edges
			List<Edge> edgesSingle = tracker.getSingleEdges();
			synchronized (edgesSingle) {
				for (Edge edge : edgesSingle) {
					g2d.setColor(edge.getColor());
					drawArrow(g2d, edge.from.x, edge.from.y, edge.to.x,
							edge.to.y, false);
				}
			}

			// Draw Nodes
			List<JitterNode> nodes = tracker.getNodes();
			Vector<String> toBeRemoved = new Vector<String>();
			synchronized (nodes) {
				for (JitterNode node : nodes) {
					if (node instanceof LsaNode) {
						String label = node.getLabel();

						int maxWidth = 0;
						int maxLines = 0;
						for (String line : label.split("\n")) {
							maxLines++;
							int w = (int) (fm.stringWidth(line) * 1.0f);
							if (w > maxWidth)
								maxWidth = w;
						}

						node.width = maxWidth;
						node.height = ((int) (fh * 1.4f)) * maxLines;
						int w2 = node.width / 2;
						int h2 = node.height / 2;

						if (!((LsaNode) node).decayed) {
							g2d.setColor(node.color);
							g2d.fillRoundRect(node.x - w2, node.y - h2,
									node.width, node.height, 10, 10);

							g2d.setColor(node.borderColor);
							g2d.drawRoundRect(node.x - w2 - 1, node.y - h2 - 1,
									node.width + 1, node.height + 1, 10, 10);

							if (node.isFixed) {
								g2d.drawRoundRect(node.x - w2 - 1, node.y - h2
										- 1, node.width + 1, node.height + 1,
										10, 10);
							}

							g2d.setColor(node.textColor);
							int l = (int) (fh * 1.4f);
							if (maxLines == 2)
								l = (int) ((fh * 1.4f) * 0.5);
							if (maxLines == 4)
								l = (int) ((fh * 1.4f) * 1.5);

							boolean isId = true;
							for (String line : label.split("\n")) {
								Font oldFont = g2d.getFont();
								if (isId) {
									Font boldFont = new Font(g2d.getFont()
											.getFontName(), Font.BOLD, g2d
											.getFont().getSize());
									g2d.setFont(boldFont);
									g2d.drawString(line,
											node.x - fm.stringWidth(line) / 2,
											node.y + fh2 - 3 - l);
									isId = false;
									g2d.setFont(oldFont);
								} else
									g2d.drawString(line, node.x
											- (maxWidth / 2) + 3, node.y + fh2
											- 3 - l);
								l -= (int) (fh * 1.4f);
							}

						}

						if (((LsaNode) node).propagated) {

							g2d.setColor(Color.RED);
							int l = (int) ((fh * 1.4f) * 0.5);
							Font oldFont = g2d.getFont();
							Font boldFont = new Font(g2d.getFont()
									.getFontName(), Font.BOLD, g2d.getFont()
									.getSize() + 8);
							g2d.setFont(boldFont);
							g2d.drawString(PROPAGATION_MSG, node.x
									- (maxWidth / 2) + 3, node.y + fh2 - 3 - l);
							g2d.setFont(oldFont);

						}

						if (((LsaNode) node).decayed) {

							g2d.setPaint(node.color);
							g2d.fillRoundRect(node.x - w2, node.y - h2,
									node.width, node.height, 10, 10);
							g2d.setPaint(SapereColors.WhiteTransparent);
							g2d.fillRoundRect(node.x - w2, node.y - h2,
									node.width, node.height, 10, 10);
							g2d.setColor(node.borderColor);
							g2d.drawRoundRect(node.x - w2 - 1, node.y - h2 - 1,
									node.width + 1, node.height + 1, 10, 10);

							g2d.setColor(new Color(0, 0, 0, 10));
							int l = (int) (fh * 1.4f);
							if (maxLines == 2)
								l = (int) ((fh * 1.4f) * 0.5);
							if (maxLines == 4)
								l = (int) ((fh * 1.4f) * 1.5);
							boolean isId = true;
							for (String line : label.split("\n")) {
								Font oldFont = g2d.getFont();
								if (isId) {
									Font boldFont = new Font(g2d.getFont()
											.getFontName(), Font.BOLD, g2d
											.getFont().getSize());
									g2d.setFont(boldFont);
									g2d.drawString(line,
											node.x - fm.stringWidth(line) / 2,
											node.y + fh2 - 3 - l);
									isId = false;
									g2d.setFont(oldFont);
								} else
									g2d.drawString(line, node.x
											- (maxWidth / 2) + 3, node.y + fh2
											- 3 - l);
								l -= (int) (fh * 1.4f);
							}

							// g2d.setColor(node.borderColor);
							g2d.setColor(Color.RED);
							Font oldFont = g2d.getFont();
							Font boldFont = new Font(g2d.getFont()
									.getFontName(), Font.BOLD, g2d.getFont()
									.getSize() + 8);
							g2d.setFont(boldFont);
							l = (int) ((fh * 1.4f) * 0.5);
							g2d.drawString(DECAY_MSG, node.x - (maxWidth / 2)
									+ 3, node.y + fh2 - 3 - l);

							((LsaNode) node).ttl--;
							if (((LsaNode) node).ttl == 0)
								toBeRemoved.add(((VisualLSA) (node
										.getUserObject())).getLsaId());

							g2d.setFont(oldFont);
						} // end decayed

					}
				}
			}

			// Remove all nodes
			for (String lsa : toBeRemoved)
				tracker.removeComponentEdges(lsa);

		}

	}

	static final int ARR_SIZE = 8;

	private void drawArrow(Graphics2D g, int x1, int y1, int x2, int y2,
			boolean doubleEdge) {
		if (x2 - x1 == 0)
			return;

		double dx = x2 - x1, dy = y2 - y1;
		double angle = Math.atan2(dy, dx);
		int len = (int) Math.sqrt(dx * dx + dy * dy);

		AffineTransform a = g.getTransform();

		double flatmatrix[] = { 0, 0, 0, 0, 0, 0 };
		a.getMatrix(flatmatrix);
		AffineTransform at = AffineTransform.getTranslateInstance(x1, y1);
		at.concatenate(AffineTransform.getRotateInstance(angle));
		g.transform(at);

		// Draw horizontal arrow starting in (0, 0)
		g.drawLine(0, 0, len, 0);

		if (doubleEdge) {
			g.fillPolygon(new int[] { len / 2 + ARR_SIZE,
					(len / 2) + ARR_SIZE - ARR_SIZE,
					(len / 2) + ARR_SIZE - ARR_SIZE, (len / 2) + ARR_SIZE },
					new int[] { 0, -ARR_SIZE, ARR_SIZE, 0 }, 4);

			g.fillPolygon(new int[] { (len / 2) - (1 * ARR_SIZE) - 3,
					(len / 2) - (1 * ARR_SIZE) - 3 + ARR_SIZE,
					(len / 2) - (1 * ARR_SIZE) - 3 + ARR_SIZE,
					(len / 2) - (1 * ARR_SIZE) - 3 }, new int[] { 0, -ARR_SIZE,
					ARR_SIZE, 0 }, 4);
		} else {
			g.fillPolygon(new int[] { len / 2, (len / 2) - ARR_SIZE,
					(len / 2) - ARR_SIZE, (len / 2) }, new int[] { 0,
					-ARR_SIZE, ARR_SIZE, 0 }, 4);
		}

		g.setTransform(a);

	}

	public void mouseClicked(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
		if (tracker != null) { // for visual code generation
			addMouseMotionListener(this);
			double bestdist = Double.MAX_VALUE;
			int x = e.getX();
			int y = e.getY();
			List<?> nodes = tracker.getNodes();
			synchronized (nodes) {
				int numberOfNodes = nodes.size();
				for (int i = 0; i < numberOfNodes; i++) {
					JitterNode n = (JitterNode) nodes.get(i);
					double dist = (n.x - x) * (n.x - x) + (n.y - y) * (n.y - y);
					if (dist < bestdist) {
						pick = n;
						bestdist = dist;
					}
				}
			}

			if (pick != null) {
				pickfixed = pick.isFixed;
				pick.isFixed = true;
				if (e.isShiftDown()) {
					pick.selected = !pick.selected;
				}
				pick.x = x;
				pick.y = y;
				repaint();
			}
			e.consume();
		}
	}

	public void mouseReleased(MouseEvent e) {
		if (tracker != null) { // for visual code generation
			removeMouseMotionListener(this);

			if (pick != null) {
				pick.x = e.getX();
				pick.y = e.getY();
				if ((e.getModifiers() & MouseEvent.BUTTON3_MASK) == MouseEvent.BUTTON3_MASK) {
					pick.isFixed = !pickfixed;
				} else {
					pick.isFixed = pickfixed;
				}
				pick = null;
				repaint();
			}

			e.consume();
		}
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mouseDragged(MouseEvent e) {
		if (pick != null) {
			pick.x = e.getX();
			pick.y = e.getY();
			repaint();
		}
		e.consume();
	}

	public void mouseMoved(MouseEvent e) {
	}

	private void formComponentResized(java.awt.event.ComponentEvent evt) {
		Dimension size = evt.getComponent().getSize();
		Double x = new Double(size.getWidth() / 2);
		Double y = new Double(size.getHeight() / 2);
		JitterNode.defaultX = x.intValue();
		JitterNode.defaultY = y.intValue();
	}

	public void run() {
		while (animation == Thread.currentThread()) {
			animate();
			repaint();

			LSAList l = tracker.getList();
			l.model.clear();
			Enumeration<VisualLSA> en = tracker.getCompHash();

			while (en.hasMoreElements()) {
				VisualLSA lsa = en.nextElement();
				l.addLSA(lsa.getLsaId(), lsa.getStatus());
			}

			try {
				Thread.sleep(50);
			} catch (InterruptedException e) {
				break;
			}
		}
	} // ------------------------------------------------------------

	public double getAnimationStressFactor() {
		return animationStressFactor;
	}

	/**
	 * 
	 * @param animationStressFactor
	 */
	public void setAnimationStressFactor(double animationStressFactor) {
		this.animationStressFactor = animationStressFactor;
	}

	public int getConnectionForce() {
		return connectionForce;
	}

	/**
	 * 
	 * @param connectionForce
	 */
	public void setConnectionForce(int connectionForce) {
		this.connectionForce = connectionForce;
	}

	public int getDistractionForce() {
		return distractionForce;
	}

	/**
	 * 
	 * @param distractionForce
	 */
	public void setDistractionForce(int distractionForce) {
		this.distractionForce = distractionForce;
	}

	public int getSamePositionForce() {
		return samePositionForce;
	}

	/**
	 * 
	 * @param samePositionForce
	 */
	public void setSamePositionForce(int samePositionForce) {
		this.samePositionForce = samePositionForce;
	}

	public int getShearForce() {
		return shearForce;
	}

	/**
	 * 
	 * @param shearForce
	 */
	public void setShearForce(int shearForce) {
		this.shearForce = shearForce;
	}

	public void keyTyped(KeyEvent e) {
	}

	public void keyPressed(KeyEvent e) {
	}

	public void keyReleased(KeyEvent e) {
		System.out.println("Key Pressed: " + e.getKeyChar());
	}
}
