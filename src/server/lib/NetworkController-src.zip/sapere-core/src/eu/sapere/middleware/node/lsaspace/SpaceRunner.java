package eu.sapere.middleware.node.lsaspace;

import eu.sapere.middleware.node.INodeManager;

/**
 * Manages the local LSA space life cicle
 * 
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class SpaceRunner implements Runnable {

	private boolean stop = false;

	private long sleepTime;

	/** The node manger */
	private INodeManager nodeManager;

	/** The Operation Manager */
	private OperationManager operationManager = null;

	/** The eco-laws engine */
	private EcoLawsEngine ecoLawsEngine = null;
	
	private SpaceView spaceView = null;

	/**
	 * Creates an instance of the SpaceRunner and initializes the
	 * OperationManager and the Ecolaws Engine
	 * 
	 * @param node
	 *            a reference to the local Node
	 * @param opTime
	 *            the operation time for the OperationManager
	 * @param sleepTime
	 *            the sleepTime for each Middleware Cicle
	 */
	public SpaceRunner(INodeManager node, long opTime, long sleepTime) {
		this.sleepTime = sleepTime;

		// Operation Manager
		operationManager = new OperationManager(node.getSpace(),
				node.getNotifier(), opTime);

		nodeManager = node;
		
		spaceView = new SpaceView();
	}

	/**
	 * Starts the eco law engine.
	 */
	public void initialiseEcoLawEngine() {
		ecoLawsEngine = new EcoLawsEngine(nodeManager);
	}

	@Override
	public void run() {

		while (!stop) {

			try {

				operationManager.exec();
				ecoLawsEngine.exec();
				// fdea
				// publish the visual space
				spaceView.updateVisualSpace(nodeManager.getSpace().getInternalSpace());

				Thread.sleep(sleepTime);
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}

	/**
	 * @return true if the SpaceRunner is stopped, false otherwise
	 */
	public boolean isStop() {
		return stop;
	}

	/**
	 * Stops the SpaceRunner
	 */
	public void stop() {
		this.stop = true;
	}

	/**
	 * @return a reference to the OperationManager
	 */
	public OperationManager getOperationManager() {
		return operationManager;
	}

	/**
	 * @return a reference to the EcoLawsEngine
	 */
	public EcoLawsEngine getEcoLawsEngine() {
		return ecoLawsEngine;
	}

}