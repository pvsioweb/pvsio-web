/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package eu.sapere.console.implementation.inspector;

import java.awt.Color;

/**
 * 
 * @author root
 */
public abstract class Node {

	/**
	 * Returns true if this element is disabled, i.e. it is excluded from the
	 * visualisation and relaxing process.
	 * 
	 * @return ?
	 */
	public boolean isDisabled() {
		return disabled;
	}

	/**
	 * A disabled element is excluded from the visualisation and relaxing
	 * process.
	 * 
	 * @param flag
	 */

	public void setDisabled(boolean flag) {
		disabled = flag;
	}

	/**
	 * Returns the inverse color to make the text printed on top of this node
	 * visible for any background color.
	 * 
	 * @return
	 */
	@SuppressWarnings("javadoc")
	public Color getInverseColor() {
		// use stored or calc colors!!
		Color c = color;
		return new Color(255 - c.getRed(), 255 - c.getGreen(),
				255 - c.getBlue());
	}

	/**
	 * 
	 * @return
	 */
	@SuppressWarnings("javadoc")
	public abstract String getLabel();

	// ------------------------------------------------------------
	// Member variables

	/**
     * 
     */
	protected boolean disabled = false;
	/**
     * 
     */
	protected boolean selected = false;
	/**
     * 
     */
	protected boolean isFixed = false;
	/**
     * 
     */
	protected Color color = Color.black;
	protected Color borderColor = Color.black;
	protected Color textColor = Color.black;
}
