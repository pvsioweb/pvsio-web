package eu.sapere.console.implementation.visual;

import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import eu.sapere.middleware.lsa.Lsa;

/**
 * Provides a textual representation of the content of the local LSA space
 * 
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class TextPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	JTextArea lsastext, reactstext;

	/**
	 * Creates an instance of the Panel
	 */
	public TextPanel() {
		super();
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		lsastext = new JTextArea();
		lsastext.setEditable(false);
		reactstext = new JTextArea();
		reactstext.setEditable(false);
		JLabel lsaslabel = new JLabel("LSA Space content");

		JScrollPane lsaspane = new JScrollPane(lsastext);
		// JScrollPane reactspane = new JScrollPane(reactstext);

		add(lsaslabel);

		add(lsaspane);
	}

	/**
	 * Updates the Monitor, printing the given list of LSA
	 * 
	 * @param list
	 *            the list of LSA to show
	 */
	public void update(final Lsa[] list) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				String tmp = "";
				for (Lsa e : list) {
					tmp += e.toString() + "\n";
				}
				lsastext.setText(tmp);
			}

		});
	}

}
