package eu.sapere.console.implementation.inspector;

import java.awt.Color;

public class SapereColors {

	public static final Color WhiteTransparent = new Color(255, 255, 255, 230);

	public static final Color VioletFilling = new Color(204, 153, 255);
	public static final Color VioletFillingTrasparent = new Color(204, 153,
			255, 80);
	public static final Color VioletBorder = new Color(112, 48, 160);
	public static final Color VioletBorderTransparent = new Color(112, 48, 160,
			80);

	public static final Color GreenFilling = new Color(181, 203, 133);
	public static final Color GreenBorder = new Color(104, 128, 55);

	public static final Color BlueFilling = new Color(175, 194, 218);
	public static final Color BlueBorder = new Color(80, 123, 175);

	public static final Color OrangeFilling = new Color(248, 181, 126);
	public static final Color OrangeBorder = new Color(217, 104, 13);

	public static final Color PetrolFilling = new Color(113, 191, 210);
	public static final Color PetrolBorder = new Color(40, 112, 130);

	public static Color fillings[] = { GreenFilling, VioletFilling,
			BlueFilling, OrangeFilling, PetrolFilling };

	public static Color borders[] = { GreenBorder, VioletBorder, BlueBorder,
			OrangeBorder, PetrolBorder };

}