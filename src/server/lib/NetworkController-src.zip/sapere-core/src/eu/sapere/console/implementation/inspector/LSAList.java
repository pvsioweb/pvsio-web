package eu.sapere.console.implementation.inspector;

import java.util.HashMap;

import javax.swing.DefaultListModel;
import javax.swing.JList;

public class LSAList extends JList<String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7501447200952318655L;

	DefaultListModel<String> model; // only lsaId
	HashMap<String, String> map = null;

	public LSAList() {
		super.setModel(this.model = new DefaultListModel<String>());
		map = new HashMap<String, String>();
	}

	public void addLSA(String lsaId, String annotation) {
		model.add(0, lsaId + " " + annotation);
	}

	public void setLSA(String lsaId, String annotation) {
		for (Object lsa : model.toArray()) {
			if (((String) lsa).startsWith(lsaId))
				model.removeElement(lsa);
			model.addElement(lsaId + " " + annotation);
		}

	}

	// FIX
	public void removeLSA(String lsaId) {
		model.removeElement(lsaId);
	}
}
