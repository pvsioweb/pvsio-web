package eu.sapere.middleware.lsa.exception;

/**
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class MalformedDescriptionException extends RuntimeException {

	private static final long serialVersionUID = 3733864237652625319L;
}
