package eu.sapere.util;

import java.io.FileInputStream;
import java.util.Properties;

/**
 * Provides the System Configuration singleton for J2SE devices. The
 * configuration file is locates in conf/settings.properties 
 * 
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class SystemConfiguration extends AbstractSystemConfiguration {

	static private String GLOBAL_PROP_FILE_NAME = "./conf/settings.properties";

	// private constructor for the singleton object
	private SystemConfiguration() {

		properties = new Properties();

		try {

			java.io.InputStream is;
			is = SystemConfiguration.class.getResourceAsStream("./conf/settings.properties");
			properties.load(is);

		} catch (Exception e) {
			System.err.println("Error while reading property files: "
					+ GLOBAL_PROP_FILE_NAME);
		}
	}

	/**
	 * Retrieves current system configuration.
	 * 
	 * @return The configuration.
	 */
	public final static SystemConfiguration getInstance() {
		if (instance == null)
			instance = new SystemConfiguration();
		return (SystemConfiguration) instance;
	}

}
