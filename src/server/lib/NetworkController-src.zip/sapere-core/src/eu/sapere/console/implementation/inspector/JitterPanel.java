/*
 * jPanel.java
 *
 * Created on 15 January 2008, 16:12
 */
package eu.sapere.console.implementation.inspector;

/**
 * 
 * @author root
 */
public class JitterPanel extends javax.swing.JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9083895910266812847L;
	private DrawPanel jitterDrawingPanel = null;

	/** Creates new form jPanel */
	public JitterPanel() {

		setLayout(new java.awt.BorderLayout());

		jitterDrawingPanel = new DrawPanel();
		super.add(jitterDrawingPanel, java.awt.BorderLayout.CENTER);

	}

	/**
   * 
   */
	public void start() {
		jitterDrawingPanel.startAnimation();
	}

	/**
   * 
   */
	public void stop() {
		jitterDrawingPanel.stopAnimation();
	}

	public DrawPanel getDrawPanel() {
		return jitterDrawingPanel;
	}

}
