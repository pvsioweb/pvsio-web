package eu.sapere.middleware.node;

import eu.sapere.middleware.node.lsaspace.OperationManager;
import eu.sapere.middleware.node.lsaspace.Space;
import eu.sapere.middleware.node.networking.topology.NetworkTopologyManager;
import eu.sapere.middleware.node.networking.transmission.delivery.INetworkDeliveryManager;
import eu.sapere.middleware.node.notifier.Notifier;


public interface INodeManager {

	/**
	 * Retrieves the local Operation Manager
	 * 
	 * @return the local Operation Manager
	 */
	OperationManager getOperationManager();

	/**
	 * Retireves the local Notifier
	 * 
	 * @return the local Notifier
	 */
	Notifier getNotifier();

	/**
	 * Retrieves a reference to the network delivery manager.
	 * 
	 * @return the reference to the network delivery manager
	 */
	INetworkDeliveryManager getNetworkDeliveryManager();



	/**
	 * Returns the space associated with this host.
	 * 
	 * @return The Name of this Node
	 */
	Space getSpace();

}