package eu.sapere.console;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JTextArea;

import eu.sapere.console.implementation.TabbedPaneDemo;
import eu.sapere.console.implementation.inspector.ContentTracker;
import eu.sapere.middleware.lsa.Lsa;
import eu.sapere.middleware.node.lsaspace.console.AbstractLsaSpaceConsole;

/**
 * Provides a J2SE implementation for the SAPERE Middleware Console
 * 
 * @author Marco Santarelli (UNIBO)
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class LsaSpaceConsole extends AbstractLsaSpaceConsole {

	JTextArea lsastext, reactstext;

	private TabbedPaneDemo tabs;

	/** A Content Tracker to track the LSAs in the local space */
	private ContentTracker cTracker = null;

	/**
	 * Creates a new SpaceMonitor
	 * 
	 * @param nodeName
	 *            The name of the local Node
	 * @param hasInspector
	 *            True is the Console should display the Visual Inspector
	 */
	public LsaSpaceConsole(String nodeName, boolean hasInspector) {
		super(nodeName, hasInspector);
	}

	public void startConsole() {
		// this.nodeName = nodeName;
		cTracker = new ContentTracker();
		initConsole();
	}

	private void initConsole() {

		cTracker = new ContentTracker();

		JFrame frame = new JFrame("Node: " + nodeName);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		tabs = new TabbedPaneDemo(cTracker, inspector);

		// Add content to the window.
		frame.add(tabs, BorderLayout.CENTER);

		frame.pack();
		frame.setSize(1200, 600);
		frame.setResizable(true);
		frame.setVisible(true);
	}

	/**
	 * {@inheritDoc}
	 */
	public void update(final Lsa[] list) {

		tabs.update(list);

	}

	@Override
	public boolean hasInspector() {
		return inspector;
	}

	@Override
	public void removeLsa(String lsaId) {
		if (cTracker != null)
			cTracker.removeComponent(lsaId);
	}

	@Override
	public void removeBond(String from, String to) {
		if (cTracker != null)
			cTracker.removeEdge(from, to);
	}

	@Override
	public void propagateLsa(String lsaId) {
		if (cTracker != null)
			cTracker.propagateComponent(lsaId);
	}

	@Override
	public void addBidirectionalBond(String from, String to) {
		if (cTracker != null)
			cTracker.addDoubleEdge(from, to);

	}

	@Override
	public void addUnidirectionalBond(String from, String to) {
		if (cTracker != null)
			cTracker.addSingleEdge(from, to);

	}

}
