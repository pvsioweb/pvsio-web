package eu.sapere.console.implementation;

import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import java.awt.GridLayout;

import eu.sapere.console.implementation.inspector.ContentTracker;
import eu.sapere.console.implementation.inspector.JitterPanel;
import eu.sapere.console.implementation.inspector.VisualLSA;
import eu.sapere.console.implementation.visual.TextPanel;
import eu.sapere.middleware.lsa.Lsa;

/**
 * Provides a two-tabbed Console
 * 
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class TabbedPaneDemo extends JPanel {

	private static final long serialVersionUID = -2090942542620445776L;
	private TextPanel main;
	private ContentTracker cTracker = null;

	/**
	 * Instantiates a TabbedPaneDemo
	 * 
	 * @param cTracker
	 *            The Content Tracker
	 * @param hasInspector
	 *            True if the Visual Inspector is active
	 */
	public TabbedPaneDemo(ContentTracker cTracker, boolean hasInspector) {
		super(new GridLayout(1, 1));

		JTabbedPane tabbedPane = new JTabbedPane();

		main = new TextPanel();
		tabbedPane.addTab("Visual Console", main);

		JitterPanel jitterPanel = null;

		if (hasInspector) {
			jitterPanel = new JitterPanel();
			tabbedPane.addTab("Visual Inspector", jitterPanel);
		}

		this.cTracker = cTracker;

		if (hasInspector) {
			jitterPanel.getDrawPanel().setContentTracker(cTracker);
			jitterPanel.start();
		}

		// Add the tabbed pane to this panel.
		add(tabbedPane);

		// The following line enables to use scrolling tabs.
		tabbedPane.setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
	}

	/**
	 * Updates the Console, printing the given list of LSA
	 * 
	 * @param list
	 *            The current list of LSAs
	 */
	public void update(final Lsa[] list) {

		main.update(list);

		if (cTracker != null) {
			for (Lsa l : list) {
				cTracker.addComponent(new VisualLSA(l.getId().toString(), l
						.toVisualString()));
				/*
				 * System.out.println(l.getContent().toString()); String s =
				 * l.getId().toString()+"\n"; s = s.replace(",", "\n");
				 * System.out.println(l.toVisualString());
				 */}
		} else {
			// for(Lsa l: list){}

			// cTracker.addComponent(new VisualLSA(lsa.getId().toString(),
			// lsa.toString()));
			// System.out.println(list.length+" "+ l.toString());

			// System.out.println("NULL");
		}
	}

}
