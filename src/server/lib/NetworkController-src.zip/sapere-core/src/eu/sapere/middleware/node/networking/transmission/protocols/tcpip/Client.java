package eu.sapere.middleware.node.networking.transmission.protocols.tcpip;

import java.io.ObjectOutputStream;
import java.net.Socket;

import eu.sapere.middleware.lsa.Lsa;
import eu.sapere.middleware.lsa.values.NeighbourLsa;
import eu.sapere.middleware.node.NodeManager;
import eu.sapere.util.ISystemConfiguration;

/**
 * The tcp/ip client for the Sapere network interface.
 * 
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class Client {

	Lsa deliverLsa = null;
	Lsa remoteNode = null;

	private String port = NodeManager.getSystemConfiguration().getProperties()
			.getProperty(ISystemConfiguration.NETWORK_PORT); // to be set in the
																// conf

	/**
	 * Delivers a Lsa to the node specified.
	 * 
	 * @param deliverLsa
	 *            The Lsa to be delivered.
	 * @param destinationLsa
	 *            The Lsa that describes the destination node.
	 */
	public void deliver(Lsa deliverLsa, Lsa destinationLsa) {
		this.deliverLsa = deliverLsa;

		Socket socket = null;
		try {

			socket = new Socket(destinationLsa
					.getProperty(NeighbourLsa.IP_ADDRESS.toString()).getValue()
					.elementAt(0), new Integer(port));

			ObjectOutputStream oos = new ObjectOutputStream(
					socket.getOutputStream());
			oos.writeObject(deliverLsa);
			socket.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
