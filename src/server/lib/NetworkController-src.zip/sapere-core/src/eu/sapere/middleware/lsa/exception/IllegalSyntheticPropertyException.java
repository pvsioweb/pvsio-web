package eu.sapere.middleware.lsa.exception;

/**
 * @author Gabriella Castelli (UNIMORE)
 * 
 */
public class IllegalSyntheticPropertyException extends RuntimeException {

	private static final long serialVersionUID = 8795538459310391239L;

}
