#!/bin/bash
echo "Removing PVSio-web Network Controller compiled files..."
ant clean -buildfile sapere-javaee.xml &> clean.log
rm -rf out
echo "Done!"
