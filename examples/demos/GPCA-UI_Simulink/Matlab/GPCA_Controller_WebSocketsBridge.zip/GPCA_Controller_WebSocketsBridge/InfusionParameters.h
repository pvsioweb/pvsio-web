#ifndef INFUSION_PARAMETERS_H
#define INFUSION_PARAMETERS_H

struct InfusionParameters {
    double programmedVTBI;
    double programmedDoseRate;
};

#endif